let colorlist = ['gold', 'yellow', 'turquoise', 'red']
let y
let x
let building
let Derp
let derpLeft
let derpRight

function preload(){
  derpy = loadImage("Derpy.png");
  chillDerp = loadImage("Chill Derp.png");
  chefDerp = loadImage("Chef Derp.png");
  insaneDerp = loadImage("Insane Derp.png");
  nerdDerp = loadImage("Nerd Derp.png");
  buffDerp = loadImage("Buff Derp.png");
  
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  frameRate(80)
  
  colorMode(HSB)
  
  //Center of screen
    x= windowWidth/2
    y= windowHeight/2


  //Derp width and height pending screen size
  derpWidth=windowWidth/5.888888888888889
  derpHeight= windowHeight/3.222222222222223

  //Derpy coordinates and puts derpy center of screen
  derpX = x-derpWidth/2+15
  derpY = y-derpHeight/2+35
  
  //Derpy Center 
  derpCenterX=x+windowWidth/2
  derpCenterY=x+windowHeight/2

  //Derp Left, Right, Top, Bottom
  derpLeft=derpX+23
  derpRight=derpX+derpWidth-23
  derpTop=derpY+37
  derpBottom=derpY+derpHeight-29
}


function draw() {
  background(220);
  
//block
  fill(0,0,50)
  rect(240,150,80,90)
  
//collision testing
 if(derpRight>240 && derpLeft<320 && derpBottom<240 && derpTop>150){
  text("Collision",20,40)
}


//draws derpy
  stroke(100,2,0)
    Derp=image(derpy, derpX, derpY, derpWidth, derpHeight)
    

  noStroke()
  
  
    //Derpy Hit box
  stroke(240,100,100)
line(derpLeft,derpTop,derpRight,derpTop)//Top of hit box
  
   stroke(277, 100, 50)
line(derpLeft,derpBottom,derpRight,derpBottom)//Bottom of hit box 
  
  stroke(120,100,100)  
line(derpLeft,derpTop,derpLeft,derpBottom)//Left hitbox
  
  stroke(0,100,100)
line(derpRight,derpTop,derpRight,derpBottom)//Right hitbox
  
  
  
  
// walking controls + hitbox follow

    if (keyIsPressed && key=='w'){//go up
      derpY=derpY-5
      derpTop=derpTop-5
      derpBottom=derpBottom-5
    }
    else if(keyIsPressed && key=='s'){//go down
      derpY=derpY+5
      derpTop=derpTop+5
      derpBottom=derpBottom+5
    }
    else if(keyIsPressed && key=='a'){//go left
      derpX=derpX-5
      derpLeft=derpLeft-5
      derpRight=derpRight-5
    }
    else if(keyIsPressed && key=='d'){//go right
      derpX=derpX+5
      derpLeft=derpLeft+5
      derpRight=derpRight+5
    }
  
  

 
stroke(0)



  text(derpX+ ", " + derpY, 20, 20)
 text("derpLeft"+" : "+derpLeft,20,60)
  text("derpRight"+" : "+derpRight,20,80)
  text("derpTop"+" : "+derpTop,20,100)
  text("derpBottom"+" : "+derpBottom,20,120)
  //you can always copy/paste the line above into any project to display the coordinates!

  


}
